// File Upload Middleware
// Author: MiniMax Agent

const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Ensure upload directories exist
const createUploadDirs = () => {
  const dirs = [
    'uploads',
    'uploads/videos',
    'uploads/thumbnails',
    'uploads/avatars',
    'uploads/covers',
    'uploads/ads'
  ];

  dirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`Created directory: ${dir}`);
    }
  });
};

// Create directories on startup
createUploadDirs();

// Storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = 'uploads/';
    
    // Determine upload path based on field name
    switch (file.fieldname) {
      case 'video':
        uploadPath += 'videos/';
        break;
      case 'thumbnail':
        uploadPath += 'thumbnails/';
        break;
      case 'avatar':
        uploadPath += 'avatars/';
        break;
      case 'cover':
      case 'coverImage':
        uploadPath += 'covers/';
        break;
      case 'adImage':
      case 'adVideo':
        uploadPath += 'ads/';
        break;
      default:
        uploadPath += 'misc/';
    }
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    const name = file.fieldname + '-' + uniqueSuffix + ext;
    cb(null, name);
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  const allowedTypes = {
    video: ['.mp4', '.avi', '.mov', '.mkv', '.webm'],
    thumbnail: ['.jpg', '.jpeg', '.png', '.webp'],
    avatar: ['.jpg', '.jpeg', '.png', '.webp'],
    cover: ['.jpg', '.jpeg', '.png', '.webp'],
    coverImage: ['.jpg', '.jpeg', '.png', '.webp'],
    adImage: ['.jpg', '.jpeg', '.png', '.webp'],
    adVideo: ['.mp4', '.avi', '.mov', '.mkv', '.webm']
  };
  
  const fileExtension = path.extname(file.originalname).toLowerCase();
  const allowedExtensions = allowedTypes[file.fieldname] || [];
  
  if (allowedExtensions.includes(fileExtension)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file type for ${file.fieldname}. Allowed: ${allowedExtensions.join(', ')}`), false);
  }
};

// Size limits (in bytes)
const limits = {
  fileSize: {
    video: 500 * 1024 * 1024,      // 500MB for videos
    thumbnail: 5 * 1024 * 1024,    // 5MB for thumbnails
    avatar: 2 * 1024 * 1024,       // 2MB for avatars
    cover: 5 * 1024 * 1024,        // 5MB for covers
    coverImage: 5 * 1024 * 1024,   // 5MB for cover images
    adImage: 5 * 1024 * 1024,      // 5MB for ad images
    adVideo: 100 * 1024 * 1024     // 100MB for ad videos
  }
};

// Custom size limit check
const checkFileSize = (req, file, cb) => {
  const maxSize = limits.fileSize[file.fieldname] || 10 * 1024 * 1024; // Default 10MB
  
  if (file.size > maxSize) {
    return cb(new Error(`File too large. Maximum size for ${file.fieldname}: ${Math.round(maxSize / (1024 * 1024))}MB`));
  }
  
  cb(null, true);
};

// Configure multer
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max file size
    files: 10 // Maximum 10 files per request
  }
});

// Error handling middleware
const handleMulterError = (error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        return res.status(400).json({
          success: false,
          message: 'File too large',
          error: error.message
        });
      case 'LIMIT_FILE_COUNT':
        return res.status(400).json({
          success: false,
          message: 'Too many files',
          error: error.message
        });
      case 'LIMIT_UNEXPECTED_FILE':
        return res.status(400).json({
          success: false,
          message: 'Unexpected file field',
          error: error.message
        });
      default:
        return res.status(400).json({
          success: false,
          message: 'File upload error',
          error: error.message
        });
    }
  } else if (error) {
    return res.status(400).json({
      success: false,
      message: 'File validation error',
      error: error.message
    });
  }
  next();
};

// Export upload middleware with error handling
module.exports = {
  upload,
  handleMulterError,
  // Specific upload configurations
  single: (fieldName) => [
    upload.single(fieldName),
    handleMulterError
  ],
  fields: (fields) => [
    upload.fields(fields),
    handleMulterError
  ],
  any: () => [
    upload.any(),
    handleMulterError
  ]
};

// For backward compatibility
module.exports.fields = upload.fields;
module.exports.single = upload.single;
module.exports.any = upload.any;