const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema({
  video: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Video',
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null // null for anonymous views
  },
  event: {
    type: String,
    enum: ['view', 'like', 'dislike', 'comment', 'share', 'watchtime'],
    required: true
  },
  metadata: {
    watchTime: Number, // seconds watched
    deviceType: String, // mobile, desktop, tablet
    browser: String,
    country: String,
    referrer: String,
    timestamp: {
      type: Date,
      default: Date.now
    }
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for analytics queries
analyticsSchema.index({ video: 1, date: -1 });
analyticsSchema.index({ video: 1, event: 1, date: -1 });
analyticsSchema.index({ user: 1, date: -1 });
analyticsSchema.index({ date: -1 });

module.exports = mongoose.model('Analytics', analyticsSchema);