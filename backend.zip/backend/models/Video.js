const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true,
    maxLength: [200, 'Title cannot exceed 200 characters']
  },
  description: {
    type: String,
    maxLength: [2000, 'Description cannot exceed 2000 characters']
  },
  videoUrl: {
    type: String,
    required: [true, 'Video URL is required']
  },
  thumbnail: {
    type: String,
    default: null
  },
  duration: {
    type: Number, // Duration in seconds
    default: 0
  },
  fileSize: {
    type: Number, // File size in bytes
    default: 0
  },
  quality: {
    type: String,
    enum: ['360p', '480p', '720p', '1080p', '1440p', '2160p'],
    default: '720p'
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: [
      'Entertainment', 'Education', 'Music', 'Gaming', 'Sports',
      'Technology', 'News', 'Comedy', 'Travel', 'Cooking',
      'Fashion', 'Beauty', 'Fitness', 'Science', 'Art', 'Other'
    ]
  },
  tags: [{
    type: String,
    trim: true,
    maxLength: [50, 'Tag cannot exceed 50 characters']
  }],
  views: {
    type: Number,
    default: 0
  },
  likes: {
    type: Number,
    default: 0
  },
  dislikes: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['processing', 'published', 'private', 'unlisted', 'flagged', 'deleted'],
    default: 'processing'
  },
  isMonetized: {
    type: Boolean,
    default: false
  },
  ageRestricted: {
    type: Boolean,
    default: false
  },
  allowComments: {
    type: Boolean,
    default: true
  },
  allowLikes: {
    type: Boolean,
    default: true
  },
  visibility: {
    type: String,
    enum: ['public', 'unlisted', 'private'],
    default: 'public'
  },
  language: {
    type: String,
    default: 'en'
  },
  transcriptUrl: {
    type: String,
    default: null
  },
  publishedAt: {
    type: Date,
    default: null
  },
  scheduledFor: {
    type: Date,
    default: null
  },
  metadata: {
    encoding: String,
    bitrate: Number,
    fps: Number,
    resolution: String,
    aspectRatio: String
  },
  analytics: {
    totalWatchTime: {
      type: Number,
      default: 0
    },
    averageViewDuration: {
      type: Number,
      default: 0
    },
    uniqueViewers: {
      type: Number,
      default: 0
    },
    retentionRate: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for comments
videoSchema.virtual('comments', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'video'
});

// Virtual for formatted duration
videoSchema.virtual('formattedDuration').get(function() {
  const minutes = Math.floor(this.duration / 60);
  const seconds = this.duration % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

// Virtual for engagement rate
videoSchema.virtual('engagementRate').get(function() {
  if (this.views === 0) return 0;
  return ((this.likes + this.dislikes) / this.views * 100).toFixed(2);
});

// Indexes for better performance
videoSchema.index({ user: 1, createdAt: -1 });
videoSchema.index({ category: 1, status: 1 });
videoSchema.index({ status: 1, publishedAt: -1 });
videoSchema.index({ views: -1 });
videoSchema.index({ likes: -1 });
videoSchema.index({ tags: 1 });
videoSchema.index({ title: 'text', description: 'text', tags: 'text' });

// Middleware to set publishedAt when status changes to published
videoSchema.pre('save', function(next) {
  if (this.isModified('status') && this.status === 'published' && !this.publishedAt) {
    this.publishedAt = new Date();
  }
  next();
});

// Static method to find published videos
videoSchema.statics.findPublished = function() {
  return this.find({ status: 'published', visibility: 'public' });
};

// Static method for trending videos
videoSchema.statics.findTrending = function(limit = 20) {
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  return this.find({
    status: 'published',
    visibility: 'public',
    createdAt: { $gte: oneDayAgo }
  })
  .sort({ views: -1, likes: -1 })
  .limit(limit)
  .populate('user', 'name avatar subscriberCount');
};

// Method to increment views
videoSchema.methods.incrementViews = function() {
  this.views += 1;
  return this.save();
};

module.exports = mongoose.model('Video', videoSchema);