// Ads Management Routes
// Author: MiniMax Agent

const express = require('express');
const { body, query, validationResult } = require('express-validator');
const User = require('../models/User');
const Video = require('../models/Video');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');

const router = express.Router();

// Ad Campaign Model (simplified)
const mongoose = require('mongoose');

const adCampaignSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    maxlength: 100
  },
  description: {
    type: String,
    maxlength: 500
  },
  advertiser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  adType: {
    type: String,
    enum: ['video', 'banner', 'overlay', 'sponsored'],
    required: true
  },
  targetAudience: {
    ageRange: {
      min: { type: Number, min: 13, max: 65 },
      max: { type: Number, min: 18, max: 100 }
    },
    gender: {
      type: String,
      enum: ['all', 'male', 'female', 'other']
    },
    interests: [String],
    countries: [String],
    languages: [String]
  },
  placement: {
    categories: [String], // Video categories to target
    keywords: [String],
    channels: [{ // Specific channels to target
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }],
    excludeChannels: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }]
  },
  budget: {
    dailyBudget: {
      type: Number,
      required: true,
      min: 1
    },
    totalBudget: {
      type: Number,
      required: true,
      min: 10
    },
    bidType: {
      type: String,
      enum: ['cpm', 'cpc', 'cpv'], // Cost per mille, click, view
      required: true
    },
    bidAmount: {
      type: Number,
      required: true,
      min: 0.01
    }
  },
  content: {
    videoUrl: String, // For video ads
    imageUrl: String, // For banner ads
    headline: String,
    description: String,
    callToAction: String,
    destinationUrl: String
  },
  schedule: {
    startDate: {
      type: Date,
      required: true
    },
    endDate: Date,
    timezone: {
      type: String,
      default: 'UTC'
    },
    dayParting: [{
      day: {
        type: String,
        enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
      },
      hours: [{
        start: Number, // 0-23
        end: Number    // 0-23
      }]
    }]
  },
  status: {
    type: String,
    enum: ['draft', 'pending_approval', 'active', 'paused', 'completed', 'rejected'],
    default: 'draft'
  },
  performance: {
    impressions: { type: Number, default: 0 },
    clicks: { type: Number, default: 0 },
    views: { type: Number, default: 0 },
    conversions: { type: Number, default: 0 },
    spend: { type: Number, default: 0 },
    ctr: { type: Number, default: 0 }, // Click-through rate
    cpm: { type: Number, default: 0 }, // Cost per mille
    cpc: { type: Number, default: 0 }, // Cost per click
    cpv: { type: Number, default: 0 }  // Cost per view
  },
  moderation: {
    reviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    reviewedAt: Date,
    rejectionReason: String
  }
}, {
  timestamps: true
});

// Indexes
adCampaignSchema.index({ advertiser: 1 });
adCampaignSchema.index({ status: 1 });
adCampaignSchema.index({ 'schedule.startDate': 1, 'schedule.endDate': 1 });
adCampaignSchema.index({ 'targetAudience.categories': 1 });

const AdCampaign = mongoose.model('AdCampaign', adCampaignSchema);

// @route   GET /api/ads/campaigns
// @desc    Get ad campaigns (user's own campaigns)
// @access  Private
router.get('/campaigns', auth, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      status,
      adType
    } = req.query;

    let query = { advertiser: req.user.id };
    if (status) query.status = status;
    if (adType) query.adType = adType;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const campaigns = await AdCampaign.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const totalCampaigns = await AdCampaign.countDocuments(query);
    const totalPages = Math.ceil(totalCampaigns / limit);

    res.json({
      success: true,
      data: {
        campaigns,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalCampaigns,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        }
      }
    });
  } catch (error) {
    console.error('Get campaigns error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching campaigns'
    });
  }
});

// @route   POST /api/ads/campaigns
// @desc    Create new ad campaign
// @access  Private
router.post('/campaigns', [
  auth,
  body('title')
    .notEmpty()
    .withMessage('Campaign title is required')
    .isLength({ max: 100 })
    .withMessage('Title cannot exceed 100 characters'),
  body('adType')
    .isIn(['video', 'banner', 'overlay', 'sponsored'])
    .withMessage('Invalid ad type'),
  body('budget.dailyBudget')
    .isFloat({ min: 1 })
    .withMessage('Daily budget must be at least $1'),
  body('budget.totalBudget')
    .isFloat({ min: 10 })
    .withMessage('Total budget must be at least $10'),
  body('budget.bidType')
    .isIn(['cpm', 'cpc', 'cpv'])
    .withMessage('Invalid bid type'),
  body('schedule.startDate')
    .isISO8601()
    .withMessage('Invalid start date')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const campaignData = {
      ...req.body,
      advertiser: req.user.id,
      status: 'draft'
    };

    const campaign = new AdCampaign(campaignData);
    await campaign.save();

    res.status(201).json({
      success: true,
      message: 'Campaign created successfully',
      data: { campaign }
    });
  } catch (error) {
    console.error('Create campaign error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating campaign'
    });
  }
});

// @route   PUT /api/ads/campaigns/:id
// @desc    Update ad campaign
// @access  Private (Campaign owner)
router.put('/campaigns/:id', auth, async (req, res) => {
  try {
    const campaign = await AdCampaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: 'Campaign not found'
      });
    }

    // Check if user owns the campaign
    if (campaign.advertiser.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to edit this campaign'
      });
    }

    // Don't allow editing active campaigns
    if (campaign.status === 'active') {
      return res.status(400).json({
        success: false,
        message: 'Cannot edit active campaigns. Pause the campaign first.'
      });
    }

    // Update campaign
    Object.keys(req.body).forEach(key => {
      if (key !== 'advertiser' && key !== 'performance') {
        campaign[key] = req.body[key];
      }
    });

    await campaign.save();

    res.json({
      success: true,
      message: 'Campaign updated successfully',
      data: { campaign }
    });
  } catch (error) {
    console.error('Update campaign error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating campaign'
    });
  }
});

// @route   PUT /api/ads/campaigns/:id/status
// @desc    Change campaign status (pause, resume, submit for approval)
// @access  Private (Campaign owner)
router.put('/campaigns/:id/status', [
  auth,
  body('status')
    .isIn(['pending_approval', 'active', 'paused'])
    .withMessage('Invalid status')
], async (req, res) => {
  try {
    const { status } = req.body;
    const campaign = await AdCampaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: 'Campaign not found'
      });
    }

    // Check if user owns the campaign
    if (campaign.advertiser.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to modify this campaign'
      });
    }

    // Validate status transition
    const validTransitions = {
      'draft': ['pending_approval'],
      'pending_approval': ['active', 'draft'], // Admin can approve or reject
      'active': ['paused'],
      'paused': ['active'],
      'rejected': ['draft']
    };

    if (!validTransitions[campaign.status]?.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot change status from ${campaign.status} to ${status}`
      });
    }

    campaign.status = status;
    await campaign.save();

    res.json({
      success: true,
      message: `Campaign ${status.replace('_', ' ')} successfully`,
      data: {
        campaign: {
          id: campaign._id,
          title: campaign.title,
          status: campaign.status
        }
      }
    });
  } catch (error) {
    console.error('Change campaign status error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while changing campaign status'
    });
  }
});

// @route   GET /api/ads/campaigns/:id/performance
// @desc    Get campaign performance analytics
// @access  Private (Campaign owner)
router.get('/campaigns/:id/performance', auth, async (req, res) => {
  try {
    const campaign = await AdCampaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: 'Campaign not found'
      });
    }

    // Check if user owns the campaign
    if (campaign.advertiser.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to view this campaign\'s performance'
      });
    }

    // In a real application, you would fetch detailed analytics data
    // For now, return the basic performance metrics
    const performanceData = {
      overview: campaign.performance,
      timeline: [], // Daily/hourly performance data would go here
      demographics: {}, // Audience breakdown would go here
      placements: {} // Performance by placement would go here
    };

    res.json({
      success: true,
      data: {
        campaign: {
          id: campaign._id,
          title: campaign.title,
          status: campaign.status
        },
        performance: performanceData
      }
    });
  } catch (error) {
    console.error('Get campaign performance error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching campaign performance'
    });
  }
});

// Admin routes for ad management
router.use('/admin', auth, adminAuth);

// @route   GET /api/ads/admin/campaigns
// @desc    Get all campaigns for admin review
// @access  Admin
router.get('/admin/campaigns', [
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('status').optional().isIn(['draft', 'pending_approval', 'active', 'paused', 'completed', 'rejected'])
], async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      status = 'pending_approval'
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const campaigns = await AdCampaign.find({ status })
      .populate('advertiser', 'username displayName email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const totalCampaigns = await AdCampaign.countDocuments({ status });
    const totalPages = Math.ceil(totalCampaigns / limit);

    res.json({
      success: true,
      data: {
        campaigns,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalCampaigns,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        }
      }
    });
  } catch (error) {
    console.error('Get admin campaigns error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching campaigns'
    });
  }
});

// @route   PUT /api/ads/admin/campaigns/:id/review
// @desc    Approve or reject ad campaign
// @access  Admin
router.put('/admin/campaigns/:id/review', [
  body('action')
    .isIn(['approve', 'reject'])
    .withMessage('Invalid action'),
  body('reason')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Reason cannot exceed 500 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { action, reason } = req.body;
    const campaign = await AdCampaign.findById(req.params.id)
      .populate('advertiser', 'username email');
    
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: 'Campaign not found'
      });
    }

    if (campaign.status !== 'pending_approval') {
      return res.status(400).json({
        success: false,
        message: 'Campaign is not pending approval'
      });
    }

    // Update campaign
    campaign.status = action === 'approve' ? 'active' : 'rejected';
    campaign.moderation.reviewedBy = req.user.id;
    campaign.moderation.reviewedAt = new Date();
    if (action === 'reject') {
      campaign.moderation.rejectionReason = reason;
    }

    await campaign.save();

    // Log the action
    console.log(`Admin ${req.user.username} ${action}ed campaign "${campaign.title}" by ${campaign.advertiser.username}. Reason: ${reason || 'None provided'}`);

    res.json({
      success: true,
      message: `Campaign ${action}ed successfully`,
      data: {
        campaign: {
          id: campaign._id,
          title: campaign.title,
          status: campaign.status
        }
      }
    });
  } catch (error) {
    console.error('Campaign review error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during campaign review'
    });
  }
});

// @route   GET /api/ads/admin/analytics
// @desc    Get ads platform analytics
// @access  Admin
router.get('/admin/analytics', async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    // Calculate date range
    let dateRange;
    switch (period) {
      case '7d':
        dateRange = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        dateRange = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        dateRange = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        dateRange = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    // Revenue analytics
    const revenueData = await AdCampaign.aggregate([
      {
        $match: {
          status: 'active',
          createdAt: { $gte: dateRange }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$createdAt"
            }
          },
          totalSpend: { $sum: '$performance.spend' },
          totalImpressions: { $sum: '$performance.impressions' },
          totalClicks: { $sum: '$performance.clicks' },
          campaignCount: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    // Ad type distribution
    const adTypeStats = await AdCampaign.aggregate([
      {
        $match: {
          status: { $in: ['active', 'completed'] },
          createdAt: { $gte: dateRange }
        }
      },
      {
        $group: {
          _id: '$adType',
          count: { $sum: 1 },
          totalSpend: { $sum: '$performance.spend' },
          totalImpressions: { $sum: '$performance.impressions' }
        }
      }
    ]);

    // Top advertisers
    const topAdvertisers = await AdCampaign.aggregate([
      {
        $match: {
          status: { $in: ['active', 'completed'] },
          createdAt: { $gte: dateRange }
        }
      },
      {
        $group: {
          _id: '$advertiser',
          totalSpend: { $sum: '$performance.spend' },
          campaignCount: { $sum: 1 },
          totalImpressions: { $sum: '$performance.impressions' }
        }
      },
      { $sort: { totalSpend: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'advertiserInfo'
        }
      }
    ]);

    const analytics = {
      revenue: revenueData,
      adTypes: adTypeStats,
      topAdvertisers,
      period
    };

    res.json({
      success: true,
      data: analytics
    });
  } catch (error) {
    console.error('Ads analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching ads analytics'
    });
  }
});

module.exports = router;