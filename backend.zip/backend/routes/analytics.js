const express = require('express');
const { query, validationResult } = require('express-validator');
const Video = require('../models/Video');
const User = require('../models/User');
const Analytics = require('../models/Analytics');
const { auth, adminAuth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/analytics/overview
// @desc    Get platform overview analytics
// @access  Admin
router.get('/overview', [auth, adminAuth], async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    // Calculate date range
    let startDate;
    switch (period) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      case '1y':
        startDate = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    const [platformStats, userGrowth, videoStats, engagementStats] = await Promise.all([
      // Platform overview stats
      Promise.all([
        User.countDocuments({ isActive: true }),
        Video.countDocuments({ status: 'published' }),
        Video.aggregate([{ $group: { _id: null, totalViews: { $sum: '$views' } } }]),
        Analytics.countDocuments({ date: { $gte: startDate } })
      ]),
      
      // User growth over time
      User.aggregate([
        {
          $match: {
            createdAt: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$createdAt' },
              month: { $month: '$createdAt' },
              day: { $dayOfMonth: '$createdAt' }
            },
            count: { $sum: 1 }
          }
        },
        {
          $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 }
        }
      ]),
      
      // Video upload stats
      Video.aggregate([
        {
          $match: {
            createdAt: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$createdAt' },
              month: { $month: '$createdAt' },
              day: { $dayOfMonth: '$createdAt' }
            },
            uploads: { $sum: 1 },
            views: { $sum: '$views' }
          }
        },
        {
          $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 }
        }
      ]),
      
      // Engagement analytics
      Analytics.aggregate([
        {
          $match: {
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: '$event',
            count: { $sum: 1 }
          }
        }
      ])
    ]);

    const [activeUsers, publishedVideos, totalViewsData, totalEvents] = platformStats;
    const totalViews = totalViewsData[0]?.totalViews || 0;

    res.json({
      success: true,
      analytics: {
        overview: {
          activeUsers,
          publishedVideos,
          totalViews,
          totalEvents,
          period
        },
        userGrowth,
        videoStats,
        engagementStats
      }
    });
  } catch (error) {
    console.error('Analytics overview error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching analytics overview'
    });
  }
});

// @route   GET /api/analytics/video/:id
// @desc    Get analytics for specific video
// @access  Private (video owner or admin)
router.get('/video/:id', auth, async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Check if user owns the video or is admin
    if (video.user.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only view analytics for your own videos.'
      });
    }

    const { period = '30d' } = req.query;
    
    // Calculate date range
    let startDate;
    switch (period) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    const [viewsOverTime, engagementData, deviceStats, trafficSources] = await Promise.all([
      // Views over time
      Analytics.aggregate([
        {
          $match: {
            video: video._id,
            event: 'view',
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$date' },
              month: { $month: '$date' },
              day: { $dayOfMonth: '$date' }
            },
            views: { $sum: 1 }
          }
        },
        {
          $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 }
        }
      ]),
      
      // Engagement data
      Analytics.aggregate([
        {
          $match: {
            video: video._id,
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: '$event',
            count: { $sum: 1 }
          }
        }
      ]),
      
      // Device type statistics
      Analytics.aggregate([
        {
          $match: {
            video: video._id,
            event: 'view',
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: '$metadata.deviceType',
            count: { $sum: 1 }
          }
        }
      ]),
      
      // Traffic sources
      Analytics.aggregate([
        {
          $match: {
            video: video._id,
            event: 'view',
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: '$metadata.referrer',
            count: { $sum: 1 }
          }
        },
        {
          $sort: { count: -1 }
        },
        {
          $limit: 10
        }
      ])
    ]);

    res.json({
      success: true,
      analytics: {
        video: {
          id: video._id,
          title: video.title,
          totalViews: video.views,
          totalLikes: video.likes,
          publishedAt: video.publishedAt
        },
        viewsOverTime,
        engagementData,
        deviceStats,
        trafficSources,
        period
      }
    });
  } catch (error) {
    console.error('Video analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching video analytics'
    });
  }
});

// @route   GET /api/analytics/user
// @desc    Get analytics for current user's content
// @access  Private
router.get('/user', auth, async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    // Calculate date range
    let startDate;
    switch (period) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    // Get user's videos
    const userVideos = await Video.find({ user: req.user._id }).select('_id');
    const videoIds = userVideos.map(v => v._id);

    const [overallStats, viewsOverTime, topPerformingVideos] = await Promise.all([
      // Overall user stats
      Video.aggregate([
        {
          $match: {
            user: req.user._id,
            status: 'published'
          }
        },
        {
          $group: {
            _id: null,
            totalVideos: { $sum: 1 },
            totalViews: { $sum: '$views' },
            totalLikes: { $sum: '$likes' },
            avgViews: { $avg: '$views' }
          }
        }
      ]),
      
      // Views over time for all user videos
      Analytics.aggregate([
        {
          $match: {
            video: { $in: videoIds },
            event: 'view',
            date: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$date' },
              month: { $month: '$date' },
              day: { $dayOfMonth: '$date' }
            },
            views: { $sum: 1 }
          }
        },
        {
          $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 }
        }
      ]),
      
      // Top performing videos
      Video.find({
        user: req.user._id,
        status: 'published'
      })
      .select('title views likes createdAt')
      .sort({ views: -1 })
      .limit(10)
      .lean()
    ]);

    const stats = overallStats[0] || {
      totalVideos: 0,
      totalViews: 0,
      totalLikes: 0,
      avgViews: 0
    };

    res.json({
      success: true,
      analytics: {
        overallStats: stats,
        viewsOverTime,
        topPerformingVideos,
        period
      }
    });
  } catch (error) {
    console.error('User analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user analytics'
    });
  }
});

// @route   POST /api/analytics/event
// @desc    Record analytics event
// @access  Public
router.post('/event', async (req, res) => {
  try {
    const { videoId, event, metadata = {} } = req.body;
    
    if (!videoId || !event) {
      return res.status(400).json({
        success: false,
        message: 'Video ID and event type are required'
      });
    }

    const video = await Video.findById(videoId);
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Create analytics record
    const analytics = new Analytics({
      video: videoId,
      user: req.user?._id || null,
      event,
      metadata: {
        ...metadata,
        timestamp: new Date(),
        userAgent: req.get('User-Agent'),
        ip: req.ip
      }
    });

    await analytics.save();

    res.json({
      success: true,
      message: 'Event recorded successfully'
    });
  } catch (error) {
    console.error('Record analytics event error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while recording analytics event'
    });
  }
});

module.exports = router;