const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { body, validationResult } = require('express-validator');
const Video = require('../models/Video');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = file.fieldname === 'video' 
      ? path.join(uploadsDir, 'videos')
      : path.join(uploadsDir, 'thumbnails');
    
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const fileFilter = (req, file, cb) => {
  if (file.fieldname === 'video') {
    // Accept video files
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed for video upload'), false);
    }
  } else if (file.fieldname === 'thumbnail') {
    // Accept image files for thumbnails
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed for thumbnail upload'), false);
    }
  } else {
    cb(new Error('Unexpected field'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 100 * 1024 * 1024, // 100MB default
    files: parseInt(process.env.MAX_FILES_PER_REQUEST) || 2
  }
});

// @route   POST /api/upload/video
// @desc    Upload video with metadata
// @access  Private
router.post('/video', [
  auth,
  upload.fields([
    { name: 'video', maxCount: 1 },
    { name: 'thumbnail', maxCount: 1 }
  ]),
  body('title')
    .trim()
    .isLength({ min: 1, max: 200 })
    .withMessage('Title must be between 1 and 200 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Description cannot exceed 2000 characters'),
  body('category')
    .isIn([
      'Entertainment', 'Education', 'Music', 'Gaming', 'Sports',
      'Technology', 'News', 'Comedy', 'Travel', 'Cooking',
      'Fashion', 'Beauty', 'Fitness', 'Science', 'Art', 'Other'
    ])
    .withMessage('Invalid category'),
  body('tags')
    .optional()
    .isString()
    .withMessage('Tags must be a string'),
  body('visibility')
    .optional()
    .isIn(['public', 'unlisted', 'private'])
    .withMessage('Invalid visibility setting')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Clean up uploaded files if validation fails
      if (req.files) {
        Object.values(req.files).flat().forEach(file => {
          fs.unlink(file.path, () => {});
        });
      }
      
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    if (!req.files || !req.files.video) {
      return res.status(400).json({
        success: false,
        message: 'Video file is required'
      });
    }

    const { title, description, category, tags, visibility = 'public' } = req.body;
    const videoFile = req.files.video[0];
    const thumbnailFile = req.files.thumbnail ? req.files.thumbnail[0] : null;

    // Create video URL (in production, you'd use a CDN or cloud storage)
    const videoUrl = `/uploads/videos/${videoFile.filename}`;
    const thumbnailUrl = thumbnailFile ? `/uploads/thumbnails/${thumbnailFile.filename}` : null;

    // Parse tags
    const videoTags = tags ? tags.split(',').map(tag => tag.trim()).filter(tag => tag) : [];

    // Create video document
    const video = new Video({
      title,
      description,
      category,
      tags: videoTags,
      videoUrl,
      thumbnail: thumbnailUrl,
      visibility,
      user: req.user._id,
      fileSize: videoFile.size,
      status: 'published' // In production, you might want 'processing' first
    });

    await video.save();

    // Populate user data for response
    await video.populate('user', 'name avatar');

    res.status(201).json({
      success: true,
      message: 'Video uploaded successfully',
      video
    });
  } catch (error) {
    console.error('Video upload error:', error);
    
    // Clean up uploaded files on error
    if (req.files) {
      Object.values(req.files).flat().forEach(file => {
        fs.unlink(file.path, () => {});
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Server error during video upload'
    });
  }
});

// @route   POST /api/upload/thumbnail
// @desc    Upload thumbnail for existing video
// @access  Private
router.post('/thumbnail/:videoId', [
  auth,
  upload.single('thumbnail')
], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Thumbnail file is required'
      });
    }

    const video = await Video.findById(req.params.videoId);
    if (!video) {
      fs.unlink(req.file.path, () => {}); // Clean up uploaded file
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Check if user owns the video or is admin
    if (video.user.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      fs.unlink(req.file.path, () => {}); // Clean up uploaded file
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only update your own videos.'
      });
    }

    // Delete old thumbnail if exists
    if (video.thumbnail) {
      const oldThumbnailPath = path.join(__dirname, '..', video.thumbnail);
      fs.unlink(oldThumbnailPath, () => {});
    }

    // Update video with new thumbnail
    video.thumbnail = `/uploads/thumbnails/${req.file.filename}`;
    await video.save();

    res.json({
      success: true,
      message: 'Thumbnail updated successfully',
      thumbnail: video.thumbnail
    });
  } catch (error) {
    console.error('Thumbnail upload error:', error);
    
    // Clean up uploaded file on error
    if (req.file) {
      fs.unlink(req.file.path, () => {});
    }
    
    res.status(500).json({
      success: false,
      message: 'Server error during thumbnail upload'
    });
  }
});

// @route   DELETE /api/upload/video/:id
// @desc    Delete video and associated files
// @access  Private
router.delete('/video/:id', auth, async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Check if user owns the video or is admin
    if (video.user.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only delete your own videos.'
      });
    }

    // Delete video file
    if (video.videoUrl) {
      const videoPath = path.join(__dirname, '..', video.videoUrl);
      fs.unlink(videoPath, () => {});
    }

    // Delete thumbnail file
    if (video.thumbnail) {
      const thumbnailPath = path.join(__dirname, '..', video.thumbnail);
      fs.unlink(thumbnailPath, () => {});
    }

    // Delete video document
    await Video.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: 'Video deleted successfully'
    });
  } catch (error) {
    console.error('Delete video error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during video deletion'
    });
  }
});

// @route   GET /api/upload/user-videos
// @desc    Get current user's uploaded videos
// @access  Private
router.get('/user-videos', auth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 12;
    const skip = (page - 1) * limit;
    const { status } = req.query;

    let query = { user: req.user._id };
    if (status) {
      query.status = status;
    }

    const videos = await Video.find(query)
      .populate('user', 'name avatar')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const total = await Video.countDocuments(query);

    res.json({
      success: true,
      videos,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit),
        totalVideos: total
      }
    });
  } catch (error) {
    console.error('Get user videos error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user videos'
    });
  }
});

module.exports = router;