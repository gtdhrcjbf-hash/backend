const express = require('express');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Video = require('../models/Video');
const { auth } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/users/:id
// @desc    Get user profile by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password -preferences')
      .lean();

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (!user.isActive) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get user's public videos
    const videos = await Video.find({
      user: user._id,
      status: 'published',
      visibility: 'public'
    })
    .select('title thumbnail views likes createdAt duration')
    .sort({ createdAt: -1 })
    .limit(12)
    .lean();

    res.json({
      success: true,
      user: {
        ...user,
        videoCount: videos.length
      },
      videos
    });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user profile'
    });
  }
});

// @route   GET /api/users/:id/videos
// @desc    Get user's videos with pagination
// @access  Public
router.get('/:id/videos', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 12;
    const skip = (page - 1) * limit;

    const user = await User.findById(req.params.id);
    if (!user || !user.isActive) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const videos = await Video.find({
      user: user._id,
      status: 'published',
      visibility: 'public'
    })
    .populate('user', 'name avatar')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();

    const total = await Video.countDocuments({
      user: user._id,
      status: 'published',
      visibility: 'public'
    });

    res.json({
      success: true,
      videos,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit),
        totalVideos: total
      }
    });
  } catch (error) {
    console.error('Get user videos error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user videos'
    });
  }
});

// @route   GET /api/users/:id/stats
// @desc    Get user statistics
// @access  Private (own stats) / Public (basic stats)
router.get('/:id/stats', auth, async (req, res) => {
  try {
    const userId = req.params.id;
    const isOwnProfile = req.user._id.toString() === userId;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get video statistics
    const videoStats = await Video.aggregate([
      {
        $match: {
          user: user._id,
          status: 'published'
        }
      },
      {
        $group: {
          _id: null,
          totalVideos: { $sum: 1 },
          totalViews: { $sum: '$views' },
          totalLikes: { $sum: '$likes' },
          avgViews: { $avg: '$views' }
        }
      }
    ]);

    const stats = videoStats[0] || {
      totalVideos: 0,
      totalViews: 0,
      totalLikes: 0,
      avgViews: 0
    };

    // If viewing own profile, include additional private stats
    if (isOwnProfile || req.user.role === 'admin') {
      // Get monthly view trends (last 12 months)
      const monthlyStats = await Video.aggregate([
        {
          $match: {
            user: user._id,
            status: 'published',
            createdAt: {
              $gte: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000)
            }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$createdAt' },
              month: { $month: '$createdAt' }
            },
            views: { $sum: '$views' },
            videos: { $sum: 1 }
          }
        },
        {
          $sort: { '_id.year': 1, '_id.month': 1 }
        }
      ]);

      stats.monthlyStats = monthlyStats;
    }

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get user stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user statistics'
    });
  }
});

// @route   PUT /api/users/:id/avatar
// @desc    Update user avatar
// @access  Private (own profile only)
router.put('/:id/avatar', [
  auth,
  body('avatar').isURL().withMessage('Avatar must be a valid URL')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const userId = req.params.id;
    
    // Check if user is updating own profile or is admin
    if (req.user._id.toString() !== userId && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only update your own avatar.'
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    user.avatar = req.body.avatar;
    await user.save();

    res.json({
      success: true,
      message: 'Avatar updated successfully',
      avatar: user.avatar
    });
  } catch (error) {
    console.error('Update avatar error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating avatar'
    });
  }
});

// @route   GET /api/users/search
// @desc    Search users
// @access  Public
router.get('/search', async (req, res) => {
  try {
    const { q, page = 1, limit = 20 } = req.query;
    
    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const users = await User.find({
      $and: [
        {
          $or: [
            { name: { $regex: q, $options: 'i' } },
            { bio: { $regex: q, $options: 'i' } }
          ]
        },
        { isActive: true },
        { role: 'user' } // Only show regular users in search
      ]
    })
    .select('name avatar bio subscriberCount totalViews')
    .sort({ subscriberCount: -1, totalViews: -1 })
    .skip(skip)
    .limit(parseInt(limit))
    .lean();

    const total = await User.countDocuments({
      $and: [
        {
          $or: [
            { name: { $regex: q, $options: 'i' } },
            { bio: { $regex: q, $options: 'i' } }
          ]
        },
        { isActive: true },
        { role: 'user' }
      ]
    });

    res.json({
      success: true,
      users,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit))
    });
  } catch (error) {
    console.error('Search users error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while searching users'
    });
  }
});

module.exports = router;