const express = require('express');
const { body, validationResult, query } = require('express-validator');
const Video = require('../models/Video');
const Comment = require('../models/Comment');
const Like = require('../models/Like');
const Analytics = require('../models/Analytics');
const { auth, optionalAuth, videoOwnerOrAdmin } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/videos
// @desc    Get all published videos with filtering and pagination
// @access  Public
router.get('/', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50'),
  query('category').optional().trim(),
  query('filter').optional().isIn(['trending', 'recent', 'popular']).withMessage('Invalid filter')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;
    const { category, filter, search } = req.query;

    let query = { status: 'published', visibility: 'public' };
    let sort = { createdAt: -1 };

    // Apply category filter
    if (category && category !== 'All') {
      query.category = category;
    }

    // Apply search filter
    if (search) {
      query.$text = { $search: search };
    }

    // Apply sorting filter
    switch (filter) {
      case 'trending':
        const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
        query.createdAt = { $gte: oneDayAgo };
        sort = { views: -1, likes: -1, createdAt: -1 };
        break;
      case 'popular':
        sort = { views: -1, likes: -1 };
        break;
      case 'recent':
      default:
        sort = { createdAt: -1 };
        break;
    }

    const videos = await Video.find(query)
      .populate('user', 'name avatar subscriberCount')
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .lean();

    const total = await Video.countDocuments(query);
    const totalPages = Math.ceil(total / limit);

    res.json({
      success: true,
      videos,
      pagination: {
        currentPage: page,
        totalPages,
        totalVideos: total,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Get videos error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching videos'
    });
  }
});

// @route   GET /api/videos/search
// @desc    Search videos
// @access  Public
router.get('/search', [
  query('q').notEmpty().withMessage('Search query is required'),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 50 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { q, category, duration, sortBy } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    let query = {
      status: 'published',
      visibility: 'public',
      $text: { $search: q }
    };

    // Apply additional filters
    if (category && category !== 'All') {
      query.category = category;
    }

    if (duration) {
      switch (duration) {
        case 'short':
          query.duration = { $lt: 240 }; // < 4 minutes
          break;
        case 'medium':
          query.duration = { $gte: 240, $lt: 1200 }; // 4-20 minutes
          break;
        case 'long':
          query.duration = { $gte: 1200 }; // > 20 minutes
          break;
      }
    }

    let sort = { score: { $meta: 'textScore' } };
    switch (sortBy) {
      case 'date':
        sort = { createdAt: -1 };
        break;
      case 'views':
        sort = { views: -1 };
        break;
      case 'rating':
        sort = { likes: -1 };
        break;
    }

    const videos = await Video.find(query)
      .populate('user', 'name avatar subscriberCount')
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .lean();

    const total = await Video.countDocuments(query);

    res.json({
      success: true,
      videos,
      query: q,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    });
  } catch (error) {
    console.error('Search videos error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while searching videos'
    });
  }
});

// @route   GET /api/videos/:id
// @desc    Get single video by ID
// @access  Public
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const video = await Video.findById(req.params.id)
      .populate('user', 'name avatar subscriberCount bio')
      .lean();

    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Check if video is accessible
    if (video.status !== 'published' || video.visibility === 'private') {
      if (!req.user || (req.user._id.toString() !== video.user._id.toString() && req.user.role !== 'admin')) {
        return res.status(403).json({
          success: false,
          message: 'Access denied'
        });
      }
    }

    // Check if user has liked the video
    let isLiked = false;
    if (req.user) {
      const like = await Like.findOne({
        user: req.user._id,
        targetId: video._id,
        targetType: 'video',
        type: 'like'
      });
      isLiked = !!like;
    }

    res.json({
      success: true,
      video: {
        ...video,
        isLiked
      }
    });
  } catch (error) {
    console.error('Get video error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching video'
    });
  }
});

// @route   POST /api/videos/:id/view
// @desc    Record video view
// @access  Public
router.post('/:id/view', optionalAuth, async (req, res) => {
  try {
    const video = await Video.findById(req.params.id);
    if (!video) {
      return res.status(404).json({
        success: false,
        message: 'Video not found'
      });
    }

    // Increment view count
    video.views += 1;
    await video.save();

    // Record analytics
    const analytics = new Analytics({
      video: video._id,
      user: req.user?._id || null,
      event: 'view',
      metadata: {
        deviceType: req.get('User-Agent')?.includes('Mobile') ? 'mobile' : 'desktop',
        referrer: req.get('Referer') || 'direct'
      }
    });
    await analytics.save();

    res.json({
      success: true,
      message: 'View recorded',
      views: video.views
    });
  } catch (error) {
    console.error('Record view error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while recording view'
    });
  }
});

module.exports = router;