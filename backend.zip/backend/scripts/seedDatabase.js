const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Video = require('../models/Video');
const Comment = require('../models/Comment');
require('dotenv').config();

const seedDatabase = async () => {
  try {
    console.log('🌱 Starting database seeding...');

    // Check if admin user already exists
    const existingAdmin = await User.findOne({ email: process.env.ADMIN_EMAIL || 'admin@videomax.com' });
    
    if (existingAdmin) {
      console.log('ℹ️ Admin user already exists, skipping seeding.');
      return;
    }

    // Create admin user
    const adminUser = new User({
      name: 'VideoMax Admin',
      email: process.env.ADMIN_EMAIL || 'admin@videomax.com',
      password: process.env.ADMIN_PASSWORD || 'admin123',
      role: 'admin',
      isVerified: true,
      bio: 'VideoMax platform administrator',
      avatar: 'https://ui-avatars.com/api/?name=VideoMax+Admin&background=667eea&color=fff&size=100'
    });
    await adminUser.save();
    console.log('✅ Admin user created successfully');

    // Create sample users
    const sampleUsers = [
      {
        name: 'John Doe',
        email: 'john@example.com',
        password: 'password123',
        bio: 'Content creator passionate about technology and education',
        avatar: 'https://ui-avatars.com/api/?name=John+Doe&background=667eea&color=fff&size=100',
        subscriberCount: 1250,
        totalViews: 45000,
        totalLikes: 3200
      },
      {
        name: 'Jane Smith',
        email: 'jane@example.com',
        password: 'password123',
        bio: 'Travel vlogger sharing adventures from around the world',
        avatar: 'https://ui-avatars.com/api/?name=Jane+Smith&background=764ba2&color=fff&size=100',
        subscriberCount: 2100,
        totalViews: 78000,
        totalLikes: 5600
      },
      {
        name: 'Mike Johnson',
        email: 'mike@example.com',
        password: 'password123',
        bio: 'Fitness enthusiast helping others achieve their health goals',
        avatar: 'https://ui-avatars.com/api/?name=Mike+Johnson&background=4CAF50&color=fff&size=100',
        subscriberCount: 890,
        totalViews: 32000,
        totalLikes: 2400
      }
    ];

    const createdUsers = [];
    for (const userData of sampleUsers) {
      const user = new User(userData);
      await user.save();
      createdUsers.push(user);
    }
    console.log(`✅ Created ${createdUsers.length} sample users`);

    // Create sample videos
    const sampleVideos = [
      {
        title: 'Getting Started with React - Complete Beginner Tutorial',
        description: 'Learn React from scratch in this comprehensive tutorial. Perfect for beginners who want to start their journey in modern web development.',
        category: 'Education',
        tags: ['react', 'javascript', 'tutorial', 'web development', 'beginner'],
        videoUrl: '/uploads/videos/sample-react-tutorial.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/667eea/ffffff?text=React+Tutorial',
        duration: 1800, // 30 minutes
        views: 15420,
        likes: 892,
        user: createdUsers[0]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
      },
      {
        title: 'Amazing Sunrise in the Swiss Alps - Travel Vlog',
        description: 'Join me as I capture the breathtaking sunrise over the Swiss Alps. This was truly a once-in-a-lifetime experience that I\'ll never forget.',
        category: 'Travel',
        tags: ['travel', 'switzerland', 'alps', 'sunrise', 'vlog', 'mountains'],
        videoUrl: '/uploads/videos/sample-travel-vlog.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/FF6B6B/ffffff?text=Swiss+Alps',
        duration: 720, // 12 minutes
        views: 23100,
        likes: 1456,
        user: createdUsers[1]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
      },
      {
        title: '30-Minute Full Body HIIT Workout - No Equipment Needed',
        description: 'Transform your fitness with this intense 30-minute HIIT workout. No equipment required - just your body weight and determination!',
        category: 'Fitness',
        tags: ['fitness', 'hiit', 'workout', 'bodyweight', 'health', 'exercise'],
        videoUrl: '/uploads/videos/sample-fitness-workout.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/4CAF50/ffffff?text=HIIT+Workout',
        duration: 1800, // 30 minutes
        views: 8750,
        likes: 654,
        user: createdUsers[2]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) // 1 day ago
      },
      {
        title: 'Node.js Express API Tutorial - Building RESTful Services',
        description: 'Learn how to build robust RESTful APIs using Node.js and Express. This tutorial covers everything from setup to deployment.',
        category: 'Education',
        tags: ['nodejs', 'express', 'api', 'backend', 'javascript', 'tutorial'],
        videoUrl: '/uploads/videos/sample-nodejs-tutorial.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/68A063/ffffff?text=Node.js+API',
        duration: 2400, // 40 minutes
        views: 12300,
        likes: 743,
        user: createdUsers[0]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
      },
      {
        title: 'Street Food Adventure in Bangkok - Thai Cuisine Exploration',
        description: 'Discover the incredible street food scene in Bangkok! From pad thai to mango sticky rice, we try it all in this delicious journey.',
        category: 'Travel',
        tags: ['bangkok', 'thailand', 'street food', 'cuisine', 'travel', 'food'],
        videoUrl: '/uploads/videos/sample-food-adventure.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/FF8C42/ffffff?text=Bangkok+Food',
        duration: 960, // 16 minutes
        views: 18700,
        likes: 1123,
        user: createdUsers[1]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
      },
      {
        title: 'Yoga Flow for Beginners - 20 Minute Morning Routine',
        description: 'Start your day right with this gentle 20-minute yoga flow designed specifically for beginners. Perfect for building flexibility and mindfulness.',
        category: 'Fitness',
        tags: ['yoga', 'beginners', 'morning routine', 'flexibility', 'mindfulness', 'wellness'],
        videoUrl: '/uploads/videos/sample-yoga-flow.mp4',
        thumbnail: 'https://via.placeholder.com/640x360/9C27B0/ffffff?text=Yoga+Flow',
        duration: 1200, // 20 minutes
        views: 6890,
        likes: 456,
        user: createdUsers[2]._id,
        status: 'published',
        publishedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000) // 4 days ago
      }
    ];

    const createdVideos = [];
    for (const videoData of sampleVideos) {
      const video = new Video(videoData);
      await video.save();
      createdVideos.push(video);
    }
    console.log(`✅ Created ${createdVideos.length} sample videos`);

    // Create sample comments
    const sampleComments = [
      {
        content: 'This is an excellent tutorial! Really helped me understand React concepts.',
        user: createdUsers[1]._id,
        video: createdVideos[0]._id,
        likes: 12
      },
      {
        content: 'Amazing video quality and such beautiful scenery. Makes me want to visit Switzerland!',
        user: createdUsers[0]._id,
        video: createdVideos[1]._id,
        likes: 8
      },
      {
        content: 'Just finished this workout and I\'m exhausted! Great routine though.',
        user: createdUsers[1]._id,
        video: createdVideos[2]._id,
        likes: 5
      },
      {
        content: 'Very clear explanations. Looking forward to more Node.js content!',
        user: createdUsers[2]._id,
        video: createdVideos[3]._id,
        likes: 15
      },
      {
        content: 'Now I\'m craving Thai food! The street vendors looked so friendly.',
        user: createdUsers[2]._id,
        video: createdVideos[4]._id,
        likes: 7
      }
    ];

    for (const commentData of sampleComments) {
      const comment = new Comment(commentData);
      await comment.save();
    }
    console.log(`✅ Created ${sampleComments.length} sample comments`);

    console.log('
🎉 Database seeding completed successfully!');
    console.log('
🔐 Admin Login Credentials:');
    console.log(`   Email: ${process.env.ADMIN_EMAIL || 'admin@videomax.com'}`);
    console.log(`   Password: ${process.env.ADMIN_PASSWORD || 'admin123'}`);
    console.log('\n👥 Sample User Credentials (all use password: password123):');
    console.log('   • john@example.com');
    console.log('   • jane@example.com');
    console.log('   • mike@example.com');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
  }
};

// If running this script directly
if (require.main === module) {
  mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/videomax', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    console.log('📊 Connected to MongoDB');
    await seedDatabase();
    process.exit(0);
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  });
}

module.exports = { seedDatabase };