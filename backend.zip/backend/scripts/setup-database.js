// Database Setup Script
// Author: MiniMax Agent

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Video = require('../models/Video');
const Comment = require('../models/Comment');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/viewmaxx';

async function setupDatabase() {
  try {
    // Connect to MongoDB
    console.log('Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ Connected to MongoDB');

    // Create indexes for better performance
    console.log('Creating database indexes...');
    
    // User indexes
    await User.createIndexes();
    console.log('✅ User indexes created');

    // Video indexes
    await Video.createIndexes();
    console.log('✅ Video indexes created');

    // Comment indexes
    await Comment.createIndexes();
    console.log('✅ Comment indexes created');

    // Create admin user if it doesn't exist
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@viewmaxx.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123456';
    
    const existingAdmin = await User.findOne({ email: adminEmail });
    
    if (!existingAdmin) {
      console.log('Creating admin user...');
      const adminUser = new User({
        username: 'admin',
        email: adminEmail,
        password: adminPassword,
        displayName: 'ViewMaxx Admin',
        role: 'admin',
        isVerified: true,
        status: 'active'
      });
      
      await adminUser.save();
      console.log(`✅ Admin user created with email: ${adminEmail}`);
      console.log(`⚠️  Default password: ${adminPassword}`);
      console.log(`⚠️  Please change the admin password after first login!`);
    } else {
      console.log('✅ Admin user already exists');
    }

    console.log('\n🎉 Database setup completed successfully!');
    console.log('\n📋 Setup Summary:');
    console.log('- MongoDB connection established');
    console.log('- Database indexes created');
    console.log('- Admin user configured');
    console.log('\n🚀 Your ViewMaxx platform is ready to launch!');
    
  } catch (error) {
    console.error('❌ Database setup failed:', error);
    process.exit(1);
  } finally {
    // Close the connection
    await mongoose.connection.close();
    console.log('\n👋 Database connection closed');
  }
}

// Check if this script is run directly
if (require.main === module) {
  setupDatabase();
}

module.exports = setupDatabase;