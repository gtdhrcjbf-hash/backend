# VideoMax Frontend

A complete video platform frontend with admin and user interfaces.

## 🚀 Deploy to Render

This repository is ready for deployment on Render as a static site.

### Quick Deploy
1. Fork this repository
2. Go to [Render](https://render.com)
3. Create new Static Site
4. Connect this GitHub repository
5. Deploy automatically

### Configuration
- **Build Command**: `echo "Static files ready"`
- **Publish Directory**: `public`
- **Auto-Deploy**: Enabled

## 📁 Structure

```
public/
├── index.html      # Landing page
├── admin.html      # Admin panel  
├── users.html      # User interface
└── _redirects      # URL routing

render.yaml         # Render configuration
package.json        # Project metadata
```

## 🌐 URLs After Deployment

- **Landing**: `https://your-site.onrender.com/`
- **Users**: `https://your-site.onrender.com/users`  
- **Admin**: `https://your-site.onrender.com/admin`

## 🔧 Backend Connection

Both interfaces connect to your VideoMax backend API:
- Enter your backend URL in the login forms
- Example: `https://your-backend.onrender.com`

## ✨ Features

### User Interface
- User registration and login
- Video browsing and discovery
- Video upload with drag-and-drop
- Profile management
- Mobile-responsive design

### Admin Panel
- Dashboard with statistics
- User management (activate/deactivate)
- Video moderation (view/delete)
- Secure admin authentication

### Landing Page
- Professional welcome page
- Navigation to user and admin portals
- Feature overview
- Responsive design

## 🔒 Security

- HTTPS by default on Render
- JWT token authentication
- Secure headers configuration
- Input validation and sanitization

## 💰 Cost

- **FREE** on Render static site hosting
- Includes HTTPS, CDN, and custom domains

## 🛠️ Customization

- Edit HTML files for branding
- Modify CSS for custom styling
- Update API endpoints as needed

## 📞 Support

This frontend works with any VideoMax backend deployment. Simply configure the API URL to connect to your backend service.

---

**Ready to deploy!** Click the deploy button above or follow the manual steps in the deployment guide.